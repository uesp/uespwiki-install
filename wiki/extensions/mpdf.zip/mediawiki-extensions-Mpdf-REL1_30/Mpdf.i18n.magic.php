<?php
/**
 * Internationalisation file for Mpdf extension.
 *
 * @file
 * @ingroup Extensions
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
	'mpdftags' => array( 0, 'mpdftags' ),
);

