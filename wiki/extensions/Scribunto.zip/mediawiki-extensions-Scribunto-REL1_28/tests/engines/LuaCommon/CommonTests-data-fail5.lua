-- This is invalid for mw.loadData()
return {
	[{}] = true
}
